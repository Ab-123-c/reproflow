from __future__ import annotations

import json
from pathlib import Path

from typer.testing import CliRunner

from reproflow import __version__
from reproflow.cli import app
from reproflow.capsule.loader import load_repro_spec
from reproflow.report import write_verification_report
from reproflow.sandbox.models import ExecutionEvidence
from reproflow.verifier.models import RunVerification, VerificationResult


runner = CliRunner()


def test_version_option_reports_package_version() -> None:
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0, result.stdout
    assert result.stdout.strip() == f"reproflow {__version__}"


def test_init_creates_valid_capsule(tmp_path: Path) -> None:
    path = tmp_path / "repro.yaml"
    result = runner.invoke(app, ["init", str(path), "--id", "demo", "--title", "Demo"])
    assert result.exit_code == 0, result.stdout
    spec = load_repro_spec(path)
    assert spec.metadata.id == "demo"
    assert "repro.py" in spec.files


def test_validate_json_is_machine_readable() -> None:
    spec_path = Path(__file__).resolve().parents[2] / "examples" / "unicode-username" / "repro.yaml"
    result = runner.invoke(app, ["validate", str(spec_path), "--json"])
    assert result.exit_code == 0, result.stdout
    payload = json.loads(result.stdout)
    assert payload["valid"] is True
    assert payload["schema"] == "reproflow/v1"


def test_report_command_reads_persisted_verification(tmp_path: Path) -> None:
    evidence = ExecutionEvidence(
        command="python repro.py",
        exit_code=1,
        stdout="",
        stderr="RuntimeError: boom\n",
        duration_ms=2,
        timed_out=False,
        environment_hash="abc",
    )
    verification = VerificationResult(
        reproduced=True,
        successful_runs=1,
        total_runs=1,
        stable_signature="RuntimeError:abc",
        runs=[RunVerification(matched=True, signature="RuntimeError:abc", evidence=evidence)],
    )
    write_verification_report(verification, tmp_path)
    result = runner.invoke(app, ["report", str(tmp_path)])
    assert result.exit_code == 0, result.stdout
    assert "VERIFIED REPRODUCTION" in result.stdout


def test_evidence_json_preserves_v1_fields_and_badge(tmp_path: Path) -> None:
    evidence = ExecutionEvidence(
        command="python repro.py",
        exit_code=1,
        stdout="",
        stderr="RuntimeError: boom\n",
        duration_ms=2,
        timed_out=False,
        environment_hash="abc",
    )
    verification = VerificationResult(
        reproduced=True,
        successful_runs=1,
        total_runs=1,
        stable_signature="RuntimeError:abc",
        runs=[RunVerification(matched=True, signature="RuntimeError:abc", evidence=evidence)],
    )
    write_verification_report(verification, tmp_path)
    payload = json.loads((tmp_path / "verification.json").read_text())
    assert payload["format"] == "reproflow/evidence/v1"
    assert payload["status"] == "verified"
    checked = runner.invoke(app, ["evidence", str(tmp_path), "--check"])
    assert checked.exit_code == 0
    assert json.loads(checked.stdout)["valid"] is True
    result = runner.invoke(app, ["evidence", str(tmp_path), "--json"])
    assert result.exit_code == 0
    assert json.loads(result.stdout)["format"] == "reproflow/evidence/v1"
    badge = runner.invoke(app, ["badge", str(tmp_path), "-o", str(tmp_path / "badge.svg")])
    assert badge.exit_code == 0
    assert "Verified" in (tmp_path / "badge.svg").read_text()


def test_evidence_check_rejects_inconsistent_payload(tmp_path: Path) -> None:
    path = tmp_path / "verification.json"
    path.write_text(json.dumps({"format": "reproflow/evidence/v1", "status": "verified"}))
    result = runner.invoke(app, ["evidence", str(path), "--check"])
    assert result.exit_code == 2
    assert json.loads(result.stdout)["valid"] is False


def test_matrix_requires_images(tmp_path: Path) -> None:
    spec = tmp_path / "repro.yaml"
    result = runner.invoke(app, ["matrix", str(spec), "--json"])
    assert result.exit_code == 2
