# Apply ReproFlow v0.1.0-alpha.5 in GitHub Codespaces

This ZIP is an **overlay update**. Apply it on top of the complete GitHub repository; do not treat the ZIP as a standalone clone.

## 1. Open a Codespace on the repository

Open `Ab-123-c/reproflow` in GitHub Codespaces and make sure the terminal is at the repository root:

```bash
pwd
git status
```

Recommended: start from an up-to-date `main` and use a release branch:

```bash
git checkout main
git pull --ff-only origin main
git checkout -b release/alpha5
```

## 2. Upload and overlay the ZIP

Upload `reproflow-v0.1.0-alpha.5-update.zip` into the repository root with the Codespaces file explorer, then run:

```bash
rm -rf /tmp/reproflow-alpha5
mkdir -p /tmp/reproflow-alpha5
unzip -q reproflow-v0.1.0-alpha.5-update.zip -d /tmp/reproflow-alpha5
cp -a /tmp/reproflow-alpha5/reproflow/. ./
```

The ZIP contains only files that are new or changed for alpha.5, so existing base modules remain in place.

## 3. Reinstall the editable package

```bash
python -m pip install -U pip
pip install -e ".[dev,ai]"
```

If you do not need the optional OpenAI provider:

```bash
pip install -e ".[dev]"
```

## 4. Verify the update

```bash
python -m compileall -q src/reproflow
pytest -q
git diff --check
reproflow doctor
reproflow inspect . --json
```

If Docker is available in the Codespace, also run the deterministic demo:

```bash
reproflow run examples/unicode-username/repro.yaml
```

And try the new minimizer:

```bash
reproflow minimize examples/unicode-username/repro.yaml \
  --file repro.py \
  --max-checks 20
reproflow run examples/unicode-username/repro.min.yaml
```

## 5. Review and push

```bash
git status
git diff --stat
git diff

git add pyproject.toml README.md CHANGELOG.md RELEASE_NOTES.md ROADMAP.md \
  src/reproflow tests/unit

git commit -m "Release v0.1.0-alpha.5"
git push -u origin release/alpha5
```

Then merge the branch through a pull request. After it lands on `main`:

```bash
git checkout main
git pull --ff-only origin main
git tag -a v0.1.0-alpha.5 -m "ReproFlow v0.1.0-alpha.5"
git push origin v0.1.0-alpha.5
```

## Direct-to-main alternative

For a solo repository, if you intentionally want to skip a release branch:

```bash
git checkout main
git pull --ff-only origin main
# apply the ZIP and run the verification commands above
git add -A
git commit -m "Release v0.1.0-alpha.5"
git push origin main
git tag -a v0.1.0-alpha.5 -m "ReproFlow v0.1.0-alpha.5"
git push origin v0.1.0-alpha.5
```
